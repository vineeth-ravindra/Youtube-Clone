//
//  MainViewController.swift
//  Youtube Clone
//
//  Created by Vineeth Ravindra on 6/18/17.
//  Copyright © 2017 Vineeth Ravindra. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {
    let cellIdentifier = "cellIdentifier"
    
    lazy var collectionView: UICollectionView = { [weak self] in
        guard let slf = self else { return UICollectionView() }
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: UICollectionViewFlowLayout())
        collectionView.delegate = slf
        collectionView.dataSource = slf
        collectionView.backgroundColor = .white
        collectionView.register(LandingPageCell.self , forCellWithReuseIdentifier: slf.cellIdentifier)
        return collectionView
    }()
    
    override func viewDidLoad() {
        setUpView()
        super.viewDidLoad()
    }
    
    func setUpView() {
        
        view.addSubview(collectionView)
        view.addConstraint(withFormat: "V:|[v0]|", forViews: collectionView)
        view.addConstraint(withFormat: "H:|[v0]|", forViews: collectionView)
    }

}

extension MainViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellIdentifier , for: indexPath)
        cell.backgroundColor = .blue
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: view.frame.width, height: 200)
    }
}
