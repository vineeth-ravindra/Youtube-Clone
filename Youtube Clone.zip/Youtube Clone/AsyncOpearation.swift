//
//  AsyncOpearation.swift
//  Youtube Clone
//
//  Created by Vineeth Ravindra on 6/18/17.
//  Copyright © 2017 Vineeth Ravindra. All rights reserved.
//

import Foundation

typealias JSONDictType = [String: Any]

class AsyncOpeartion: Operation {
    
    internal enum stateEnum: String {
        case ready, executing, finished
        
        var keyPath: String {
            return "is" + rawValue.capitalized
        }
    }
    
    var status: stateEnum {
        willSet{
            willChangeValue(forKey: newValue.keyPath)
            willChangeValue(forKey: status.keyPath)
        }
        didSet {
            didChangeValue(forKey: oldValue.keyPath)
            didChangeValue(forKey: status.keyPath)
        }
    }
    
    
    init(withCompletion compl: @escaping (JSONDictType) -> Void) {
        completion = compl
    }
    
    var completion: ((JSONDictType) -> Void)? = nil
    
    
    
    override var isReady: Bool {
        return status == .ready
    }
    
    override var isFinished: Bool {
        return status == .finished
    }
    
    override var isExecuting: Bool {
        return super.isExecuting && status == .executing
    }
    
    override var isAsynchronous: Bool {
        return true
    }
    
    
    override func main() {
        
    }
}
